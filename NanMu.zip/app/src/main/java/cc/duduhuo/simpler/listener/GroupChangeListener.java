package cc.duduhuo.simpler.listener;


public interface GroupChangeListener {
    /**
     * 点击了菜单（分组）
     *
     * @param menuId    菜单Id
     * @param groupId   分组Id
     * @param groupName 分组名称
     */
    void onGroupChange(int menuId, String groupId, String groupName);
}
