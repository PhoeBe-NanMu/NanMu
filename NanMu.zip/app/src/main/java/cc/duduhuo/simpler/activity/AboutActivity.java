package cc.duduhuo.simpler.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cc.duduhuo.applicationtoast.AppToast;
import cc.duduhuo.simpler.R;
import cc.duduhuo.simpler.app.App;
import cc.duduhuo.simpler.base.BaseActivity;
import cc.duduhuo.simpler.listener.OnDialogOpListener;
import cc.duduhuo.simpler.util.CommonUtils;
import cc.duduhuo.simpler.util.DialogUtil;

public class AboutActivity extends BaseActivity {
    @BindView(R.id.tvVersion)
    TextView mTvVersion;
    @BindView(R.id.tvUpdateDate)
    TextView mTvUpdateDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        ButterKnife.bind(this);
        init();
    }

    /**
     * 初始化数据
     */
    private void init() {
        //mTvVersion.setText(getString(R.string.version_name_prefix, App.getInstance().getVersionName()));
        //mTvUpdateDate.setText(App.getInstance().getUpdateDate());
    }

    public static Intent newIntent(Context context) {
        Intent intent = new Intent(context, AboutActivity.class);
        return intent;
    }


    @OnClick(R.id.tvBack)
    void back() {
        this.finish();
    }

}
