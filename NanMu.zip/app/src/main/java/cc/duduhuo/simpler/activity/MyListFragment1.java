package cc.duduhuo.simpler.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import cc.duduhuo.simpler.R;
import cc.duduhuo.simpler.view.DSwipeRefresh;

public class MyListFragment1 extends android.support.v4.app.Fragment {

    private DSwipeRefresh dSwipeRefresh;


    public MyListFragment1() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        dSwipeRefresh = (DSwipeRefresh) inflater.inflate(R.layout.item_dswiperefresh,container,false);

        return dSwipeRefresh;
    }

    @Nullable
    @Override
    public View getView() {
        return dSwipeRefresh;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        //dSwipeRefresh.setLayoutManager(new LinearLayoutManager(mRecyclerView.getContext()));
        //dSwipeRefresh.setAdapter(new RecyclerViewAdapter(getActivity()));


    }
}




















