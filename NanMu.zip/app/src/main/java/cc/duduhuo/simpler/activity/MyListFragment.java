package cc.duduhuo.simpler.activity;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import cc.duduhuo.simpler.R;
import cc.duduhuo.simpler.view.DSwipeRefresh;




public class MyListFragment extends android.support.v4.app.Fragment {
    public RecyclerView mRvStatuses;
    public DSwipeRefresh mSwipeRefresh;
    public View Myview;
    LayoutInflater inflater;

    public RecyclerView getmRvStatuses() {
        return mRvStatuses;
    }

    public DSwipeRefresh getmSwipeRefresh() {
        return mSwipeRefresh;
    }

    public View getMyview() {
        return Myview;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        //mRvStatuses = (RecyclerView) inflater.inflate(R.layout.fragment_list,container,false);
        Myview = inflater.inflate(R.layout.item_dswiperefresh,null);

        mSwipeRefresh = Myview.findViewById(R.id.swipeRefresh);
        mRvStatuses = Myview.findViewById(R.id.rvStatuses);

        return Myview;
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Nullable
    @Override
    public View getView() {
        return Myview;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //mRecyclerView.setLayoutManager(new LinearLayoutManager(mRecyclerView.getContext()));
        //mRecyclerView.setAdapter(new RecyclerViewAdapter(getActivity()));
    }

}
